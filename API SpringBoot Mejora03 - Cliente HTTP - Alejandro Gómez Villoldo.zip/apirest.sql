-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-03-2023 a las 18:09:27
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `apirest`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `category`
--

INSERT INTO `category` (`id`, `category_name`) VALUES
(1, 'comida'),
(4, 'bebida'),
(6, 'prueba01');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hibernate_sequence`
--

CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hibernate_sequence`
--

INSERT INTO `hibernate_sequence` (`next_val`) VALUES
(7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(120) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `product_category` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `product`
--

INSERT INTO `product` (`id`, `product_name`, `price`, `product_category`) VALUES
(3, 'tortillita5', 150, '1'),
(5, 'Liqueur Banana, Ramazzotti', 78.08, ''),
(6, 'Muffin Batt - Carrot Spice', 89.94, ''),
(7, 'Wine - Jackson Triggs Okonagan', 76.11, ''),
(8, 'Sprouts - Brussel', 73.45, ''),
(9, 'Garlic - Primerba, Paste', 24.59, ''),
(10, 'Soup Campbells', 54.36, ''),
(11, 'Cheese - St. Andre', 31.79, ''),
(12, 'cambio_categories', 550, '6'),
(13, 'Coffee Cup 12oz 5342cd', 93.63, ''),
(14, 'Veal - Inside - New', 550, ''),
(15, 'Beef - Roasted, Cooked', 50.88, ''),
(16, 'Octopus', 6.23, ''),
(17, 'Juice - Pineapple, 48 Oz', 82.85, ''),
(18, 'Veal - Inside', 86.73, ''),
(19, 'Beef - Rouladin, Sliced', 46.27, ''),
(20, 'Monkfish Fresh - Skin Off', 15.87, ''),
(21, 'Wine - Delicato Merlot', 88.2, ''),
(22, 'Cherries - Frozen', 71.29, ''),
(23, 'Lamb Rack - Ontario', 87.13, ''),
(24, 'Sugar - Splenda Sweetener', 96.07, ''),
(25, 'Amarula Cream', 15.09, ''),
(26, 'Chicken Breast Wing On', 32.67, ''),
(27, 'Whmis Spray Bottle Graduated', 94.47, ''),
(28, 'Beef - Striploin Aa', 3.09, ''),
(29, 'Wine - Beaujolais Villages', 47.62, ''),
(30, 'Tea - Black Currant', 12.31, ''),
(31, 'Rabbit - Legs', 32.43, ''),
(32, 'tortillita', 450, ''),
(33, 'Capon - Breast, Wing On', 46.37, ''),
(34, 'Muffin Mix - Morning Glory', 95.33, '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
